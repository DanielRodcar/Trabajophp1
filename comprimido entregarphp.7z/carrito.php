<?php
session_start();
?>
<html>
<head>
  <title>Carro de compra</title>
  <meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="carrito.css">
</head>
<body>
		<ul class="menu">
		<li><a href="inicio.php">Inicio</a><li>
		<li><a href="carrito.php">Carrito</a><li>
		<li><a href="Pedido.php">Pedidos</a><li>
		</ul>
	</br>
<?php

	if (isset($_POST['Producto'])) 
	{
		if ($_POST['Producto'] == 'Peras'){
			if (isset ($_SESSION['Peras'])){
				if (is_numeric($_POST['Cantidad'])) {
					$_SESSION['Peras'] = $_SESSION['Peras'] +  $_POST['Cantidad'];
				}
			}
			else
			{
				if (is_numeric($_POST['Cantidad'])) {
					$_SESSION['Peras'] = $_POST['Cantidad'];
				} 
			}
		}
	}
	
		if (isset($_POST['Producto'])) 
	{
		if ($_POST['Producto'] == 'Platanos'){
			if (isset ($_SESSION['Platanos'])){
				if (is_numeric($_POST['Cantidad'])) {
					$_SESSION['Platanos'] = $_SESSION['Platanos'] +  $_POST['Cantidad'];
				}
			}
			else
			{
				if (is_numeric($_POST['Cantidad'])) {
					$_SESSION['Platanos'] = $_POST['Cantidad'];
				} 
			}
		}
	}
			
	
if ( isset($_SESSION['Peras']) || isset($_SESSION['Platanos']) 
   ){
	echo "<table>\n";
	echo "<tr><th>Producto</th><th>Cantidad</th><th/></tr>\n";

	if (isset($_SESSION['Peras'])){
		echo "<tr><td> Peras </td><td>" . $_SESSION['Peras'] . "</td>\n";
	}		 
	if (isset($_SESSION['Platanos'])){
		echo "<tr><td> Platanos </td><td>" . $_SESSION['Platanos'] . "</td>\n";
	}
			 
	echo " </table>\n";	
}
else
{
	echo "El carrito está vacío\n";
	
}
?>
</br>
		<a href="inicio.php">
		<input type="button" value="Seguir comprando">
		</a> 
		<form action="pedido.php" method="post">
		<input type="submit" value="Finalizar pedido">
		<input type="hidden" name="pedido">
		</form>

		
	

</body>
</html>
