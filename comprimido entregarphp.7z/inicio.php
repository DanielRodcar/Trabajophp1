<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Inicio</title>
  <meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="inicio.css">
</head>
<body>
	<ul class="menu">
		<li><a href="inicio.php">Inicio</a><li>
		<li><a href="carrito.php">Carrito</a><li>
		<li><a href="Pedido.php">Pedidos</a><li>
		</ul>
	<center></br>
	
		<form action="carrito.php" method="post">
		Producto</br>
		<select  name="Producto">
				<option value ="Peras">Peras</option>
				<option value ="Platanos">Platanos</option>
				
			</select>
			</br></br>
			 Introduzca la cantidad que quieres comprar del articulo elegido<input type="number" name="Cantidad">
		
		<input type="submit" value="Pulsa para añadir a carrito">
		</form>
		</br>
		
				<?php
	 if (isset($_POST['peras'])) {
	 if (is_numeric($_POST['peras'])) {
	$_SESSION['carro']['peras'] = $_POST['peras'];
	 } 
	 }
	 if (isset($_POST['platanos'])) {
	 if (is_numeric($_POST['platanos']))
	{
	$_SESSION['carro']['platanos'] = $_POST['platanos'];
	 } 
	 }
	?>

		
	
	</center>


</body>
</html>