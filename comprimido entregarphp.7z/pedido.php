		<?php
session_start();
?>
	<html>
<head>
  <title>Pedidos</title>
  <meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="pedido.css">
</head>
<body>
<ul class="menu">
		<li><a href="inicio.php">Inicio</a><li>
		<li><a href="carrito.php">Carrito</a><li>
		<li><a href="Pedido.php">Pedidos</a><li>
		</ul>
	<?php
	
	unset($_SESSION['Peras']);
	unset($_SESSION['Platanos']);
		if(isset ($_POST['borrar'])){
			unset($_COOKIE['contador']);
			setcookie('contador', '', time()-3600);
			unset($_COOKIE['ultfecha']);
			setcookie('ultfecha', '', time()-3600);
			
		}
	  if(isset($_COOKIE['contador']))
	  { 
		// Caduca en un año 
			if (isset($_POST['pedido'])) {
			setcookie('contador', $_COOKIE['contador'] + 1, time() + 365 * 24 * 60 * 60); 
			
			   }
		$mensaje = 'El numero de pedidos ' . $_COOKIE['contador']; 
		
	  } 
	  else 
	  { 
		// Caduca en un año 
		if (isset($_POST['pedido'])) {
			setcookie('contador', 1, time() + 365 * 24 * 60 * 60);
				  $mensaje = 'El numero de pedidos  es 1';
		}else{
			$mensaje = 'No hay pedidos aun '; 
		}
		} 
	
    echo $mensaje."\n";
	  if(isset($_COOKIE['ultfecha']))
	  {
			  if(isset($_POST['pedido'])){
				  setcookie('ultfecha',date('F j, Y, g:i a'),time() + 365 * 24 * 60 * 60);
				   
			  }
			   $mensaje_fecha = 'La fecha del ultimo pedido es  ' . $_COOKIE['ultfecha']; 
			  }else{
			  if(isset($_POST['pedido'])){
				  setcookie('ultfecha',date('F j, Y, g:i a'),time() + 365 * 24 * 60 * 60);
				$mensaje_fecha = 'La fecha del ultimo pedido es  ' . $_COOKIE['ultfecha']; 
			  }
	else{
				  $mensaje_fecha='No hay fecha todavía';
		  
		    }
	  }
	  echo $mensaje_fecha;
	 
	
		
	
	
?> 
	<form action="pedido.php" method="post">
		<input type="submit" value="Borrar_historial" name="borrar">
	</form>
	
	
	
</body>
</html>